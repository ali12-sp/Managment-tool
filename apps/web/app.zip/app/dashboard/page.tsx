"use client";

import { useEffect, useMemo, useState } from "react";
import AppHeader from "../components/AppHeader";

type DashboardStats = {
  projectsCount: number;
  totalTasks: number;
  todoCount: number;
  inProgressCount: number;
  doneCount: number;
  overdueCount: number;
};

type Task = {
  id: string;
  title: string;
  status: "TODO" | "IN_PROGRESS" | "DONE";
  dueDate?: string | null;
  project?: { id: string; name: string } | null;
  assignee?: { id: string; email: string; name?: string | null } | null;
};

type NotificationItem = {
  id: string;
  title: string;
  body?: string | null;
  createdAt: string;
};

function getSavedOrgSlug() {
  return window.localStorage.getItem("orgSlug") ?? "my-company";
}

function getSavedToken() {
  return window.localStorage.getItem("accessToken") ?? "";
}

function formatErrorMessage(payload: any): string {
  return (
    (typeof payload?.error === "string" && payload.error) ||
    payload?.error?.formErrors?.[0] ||
    Object.values(payload?.error?.fieldErrors ?? {}).flat()?.[0] ||
    "Request failed"
  );
}

function formatDate(value?: string | null) {
  if (!value) return "No due date";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "No due date";
  return date.toLocaleDateString();
}

export default function DashboardPage() {
  const base = useMemo(
    () => process.env.NEXT_PUBLIC_API_URL ?? "http://127.0.0.1:4000",
    []
  );

  const [orgSlug, setOrgSlug] = useState("my-company");
  const [token, setToken] = useState("");
  const [error, setError] = useState("");
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [activity, setActivity] = useState<NotificationItem[]>([]);

  useEffect(() => {
    setOrgSlug(getSavedOrgSlug());
    setToken(getSavedToken());
  }, []);

  useEffect(() => {
    function onOrgChanged() {
      setOrgSlug(getSavedOrgSlug());
    }

    function onTokenChanged() {
      setToken(getSavedToken());
    }

    window.addEventListener("orgSlugChanged", onOrgChanged as EventListener);
    window.addEventListener("accessTokenChanged", onTokenChanged as EventListener);

    return () => {
      window.removeEventListener("orgSlugChanged", onOrgChanged as EventListener);
      window.removeEventListener("accessTokenChanged", onTokenChanged as EventListener);
    };
  }, []);

  async function loadOverview() {
    if (!token || !orgSlug) return;

    setError("");

    const [dashboardRes, tasksRes, notificationsRes] = await Promise.all([
      fetch(`${base}/dashboard`, {
        headers: {
          Authorization: `Bearer ${token}`,
          "x-org-slug": orgSlug,
        },
        cache: "no-store",
      }),
      fetch(`${base}/tasks`, {
        headers: {
          Authorization: `Bearer ${token}`,
          "x-org-slug": orgSlug,
        },
        cache: "no-store",
      }),
      fetch(`${base}/notifications`, {
        headers: {
          Authorization: `Bearer ${token}`,
          "x-org-slug": orgSlug,
        },
        cache: "no-store",
      }),
    ]);

    const [dashboardData, tasksData, notificationsData] = await Promise.all([
      dashboardRes.json().catch(() => null),
      tasksRes.json().catch(() => null),
      notificationsRes.json().catch(() => null),
    ]);

    if (!dashboardRes.ok) {
      setError(formatErrorMessage(dashboardData));
      setStats(null);
      return;
    }

    setStats(dashboardData?.stats ?? null);
    setTasks(tasksRes.ok ? tasksData?.tasks ?? [] : []);
    setActivity(notificationsRes.ok ? (notificationsData?.notifications ?? []).slice(0, 6) : []);
  }

  useEffect(() => {
    loadOverview();
    const timer = window.setInterval(loadOverview, 30000);
    return () => window.clearInterval(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [base, token, orgSlug]);

  const completionRate = stats?.totalTasks
    ? Math.round(((stats.doneCount ?? 0) / stats.totalTasks) * 100)
    : 0;

  const dueSoon = tasks
    .filter((task) => task.dueDate && task.status !== "DONE")
    .sort((left, right) => new Date(left.dueDate ?? 0).getTime() - new Date(right.dueDate ?? 0).getTime())
    .slice(0, 5);

  return (
  <main className="space-y-6">

    {/* HEADER SECTION */}
    <section className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">

      <div>
        <h1 className="text-3xl font-semibold text-slate-900">
          Dashboard
        </h1>
        <p className="text-sm text-slate-500 mt-1">
          Welcome back — here’s what’s happening in your workspace.
        </p>
      </div>

      {/* Completion Card */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm w-full max-w-xs">
        <p className="text-sm text-slate-500">Completion</p>
        <p className="text-3xl font-semibold mt-2">{completionRate}%</p>

        <div className="w-full h-2 bg-slate-200 rounded-full mt-3">
          <div
            className="h-full bg-green-500 rounded-full"
            style={{ width: `${completionRate}%` }}
          />
        </div>
      </div>

    </section>

    {/* ERROR */}
    {error && (
      <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-600">
        {error}
      </div>
    )}

    {!token && (
      <div className="rounded-xl border border-yellow-200 bg-yellow-50 px-4 py-3 text-sm text-yellow-700">
        Not logged in. Go to /login.
      </div>
    )}

    {/* STATS */}
    <section className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-4">

      {[
        ["Projects", stats?.projectsCount ?? 0],
        ["Tasks", stats?.totalTasks ?? 0],
        ["Todo", stats?.todoCount ?? 0],
        ["In Progress", stats?.inProgressCount ?? 0],
        ["Done", stats?.doneCount ?? 0],
        ["Overdue", stats?.overdueCount ?? 0],
      ].map(([label, value]) => (
        <div
          key={label}
          className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm"
        >
          <p className="text-sm text-slate-500">{label}</p>
          <p className="text-2xl font-semibold mt-2">{value}</p>
        </div>
      ))}

    </section>

    {/* MAIN GRID */}
    <section className="grid gap-6 xl:grid-cols-2">

      {/* TASKS */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm">

        <h2 className="text-lg font-semibold text-slate-900">
          Upcoming Tasks
        </h2>
        <p className="text-sm text-slate-500 mt-1">
          Tasks with nearest deadlines
        </p>

        <div className="mt-4 space-y-3">

          {dueSoon.length === 0 ? (
            <div className="text-sm text-slate-500 bg-slate-50 border border-dashed border-slate-300 p-4 rounded-xl">
              No upcoming tasks.
            </div>
          ) : (
            dueSoon.map((task) => (
              <div
                key={task.id}
                className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex justify-between items-center"
              >
                <div>
                  <p className="font-medium text-slate-900">
                    {task.title}
                  </p>
                  <p className="text-xs text-slate-500 mt-1">
                    {task.project?.name ?? "No project"} ·{" "}
                    {task.assignee?.name ||
                      task.assignee?.email ||
                      "Unassigned"}
                  </p>
                </div>

                <div className="text-xs text-slate-500 bg-white border px-2 py-1 rounded-md">
                  {formatDate(task.dueDate)}
                </div>
              </div>
            ))
          )}

        </div>

      </div>

      {/* ACTIVITY */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm">

        <h2 className="text-lg font-semibold text-slate-900">
          Activity
        </h2>
        <p className="text-sm text-slate-500 mt-1">
          Latest updates from your workspace
        </p>

        <div className="mt-4 space-y-3">

          {activity.length === 0 ? (
            <div className="text-sm text-slate-500 bg-slate-50 border border-dashed border-slate-300 p-4 rounded-xl">
              No activity yet.
            </div>
          ) : (
            activity.map((item) => (
              <div
                key={item.id}
                className="bg-slate-50 border border-slate-200 rounded-xl p-4"
              >
                <p className="text-sm font-medium text-slate-900">
                  {item.title}
                </p>

                {item.body && (
                  <p className="text-sm text-slate-600 mt-1">
                    {item.body}
                  </p>
                )}

                <p className="text-xs text-slate-400 mt-2">
                  {new Date(item.createdAt).toLocaleString()}
                </p>
              </div>
            ))
          )}

        </div>

      </div>

    </section>

  </main>
);
}
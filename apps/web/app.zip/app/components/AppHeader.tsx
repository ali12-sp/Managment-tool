"use client";

import { useEffect, useMemo, useState } from "react";
import NotificationCenter from "./NotificationCenter";

export default function AppHeader() {
  const base = useMemo(
    () => process.env.NEXT_PUBLIC_API_URL ?? "http://127.0.0.1:4000",
    []
  );

  const [orgSlug, setOrgSlug] = useState("my-company");
  const [token, setToken] = useState("");

  useEffect(() => {
    setOrgSlug(window.localStorage.getItem("orgSlug") ?? "my-company");
    setToken(window.localStorage.getItem("accessToken") ?? "");
  }, []);

  async function handleLogout() {
    try {
      await fetch(`${base}/auth/logout`, {
        method: "POST",
        credentials: "include",
      });
    } catch {}

    window.localStorage.removeItem("accessToken");
    window.location.href = "/login";
  }

  return (
    <header className="sticky top-0 z-30 bg-[#f5f7fb]/80 backdrop-blur-xl border-b border-slate-200">

      <div className="flex items-center justify-between px-6 py-4">

        {/* LEFT — SEARCH */}
        <div className="w-full max-w-md">
          <input
            placeholder="Search tasks..."
            className="input w-full"
          />
        </div>

        {/* RIGHT */}
        <div className="flex items-center gap-4 ml-6">

          {/* Workspace */}
          <div className="hidden md:block text-sm text-slate-600">
            {orgSlug}
          </div>

          {/* Notifications */}
          <NotificationCenter />

          {/* Profile */}
          <div className="flex items-center gap-2 bg-white px-3 py-2 rounded-xl border border-slate-200">

            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-green-400 to-green-600 text-white flex items-center justify-center text-sm font-semibold">
              U
            </div>

            <div className="hidden md:block text-sm">
              User
            </div>

          </div>

          {/* Logout */}
          {token && (
            <button
              onClick={handleLogout}
              className="btn btn-secondary"
            >
              Logout
            </button>
          )}

        </div>

      </div>

    </header>
  );
}
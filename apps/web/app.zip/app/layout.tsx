import "./globals.css";
import Sidebar from "./components/Sidebar";
import AppHeader from "./components/AppHeader";

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-slate-100 text-slate-800">

        <div className="flex min-h-screen">

          {/* Sidebar */}
          <aside className="w-64 bg-white border-r border-slate-200 flex flex-col">
            <Sidebar />
          </aside>

          {/* Main */}
          <div className="flex-1 flex flex-col">

            <div className="sticky top-0 z-20">
  <AppHeader />
</div>

            <main className="flex-1 overflow-y-auto p-6">
              {children}
            </main>

          </div>

        </div>

      </body>
    </html>
  );
}
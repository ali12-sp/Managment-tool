"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const menu = [
  { name: "Dashboard", href: "/dashboard", icon: "📊" },
  { name: "Tasks", href: "/tasks", icon: "🗂️" },
  { name: "Calendar", href: "/calendar", icon: "📅" },
  { name: "Analytics", href: "/analytics", icon: "📈" },
];

const general = [
  { name: "Settings", href: "/settings", icon: "⚙️" },
  { name: "Help", href: "/help", icon: "❓" },
  { name: "Logout", href: "/logout", icon: "🚪" },
];

export default function Sidebar() {
  const pathname = usePathname();

  return (
    <div className="h-full flex flex-col justify-between p-5">

      {/* TOP */}
      <div>
        {/* Logo */}
        <div className="flex items-center gap-2 mb-8">
          <div className="w-9 h-9 rounded-xl bg-green-600 flex items-center justify-center text-white font-bold">
            O
          </div>
          <span className="text-lg font-semibold">OpsBoard</span>
        </div>

        {/* MENU */}
        <div className="mb-6">
          <p className="text-xs text-slate-400 mb-3 uppercase tracking-wider">
            Menu
          </p>

          <nav className="flex flex-col gap-1">
            {menu.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-center gap-3 px-3 py-2 rounded-xl text-sm font-medium transition ${
                  pathname === item.href
                    ? "bg-green-100 text-green-700"
                    : "text-slate-600 hover:bg-slate-100"
                }`}
              >
                <span>{item.icon}</span>
                {item.name}
              </Link>
            ))}
          </nav>
        </div>

        {/* GENERAL */}
        <div>
          <p className="text-xs text-slate-400 mb-3 uppercase tracking-wider">
            General
          </p>

          <nav className="flex flex-col gap-1">
            {general.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="flex items-center gap-3 px-3 py-2 rounded-xl text-sm text-slate-600 hover:bg-slate-100 transition"
              >
                <span>{item.icon}</span>
                {item.name}
              </Link>
            ))}
          </nav>
        </div>
      </div>

      {/* BOTTOM CARD */}
      <div className="card p-4">

        <p className="text-sm font-medium mb-2">
          Upgrade Plan 🚀
        </p>

        <p className="text-xs text-slate-500 mb-3">
          Unlock premium features and unlimited boards.
        </p>

        <button className="btn btn-primary w-full">
          Upgrade
        </button>

      </div>

    </div>
  );
}
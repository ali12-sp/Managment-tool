"use client";

import { useEffect, useMemo, useState } from "react";

type NotificationItem = {
  id: string;
  type: string;
  title: string;
  body?: string | null;
  entityType?: string | null;
  entityId?: string | null;
  readAt?: string | null;
  createdAt: string;
};

function getSavedOrgSlug() {
  return window.localStorage.getItem("orgSlug") ?? "my-company";
}

function getSavedToken() {
  return window.localStorage.getItem("accessToken") ?? "";
}

function formatWhen(value: string) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "";
  return date.toLocaleString();
}

export default function NotificationCenter() {
  const base = useMemo(
    () => process.env.NEXT_PUBLIC_API_URL ?? "http://127.0.0.1:4000",
    []
  );

  const [open, setOpen] = useState(false);
  const [orgSlug, setOrgSlug] = useState("my-company");
  const [token, setToken] = useState("");
  const [items, setItems] = useState<NotificationItem[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setOrgSlug(getSavedOrgSlug());
    setToken(getSavedToken());
  }, []);

  useEffect(() => {
    function onOrgChanged() {
      setOrgSlug(getSavedOrgSlug());
    }

    function onTokenChanged() {
      setToken(getSavedToken());
    }

    window.addEventListener("orgSlugChanged", onOrgChanged as EventListener);
    window.addEventListener("accessTokenChanged", onTokenChanged as EventListener);

    return () => {
      window.removeEventListener("orgSlugChanged", onOrgChanged as EventListener);
      window.removeEventListener("accessTokenChanged", onTokenChanged as EventListener);
    };
  }, []);

  async function loadNotifications() {
    if (!token || !orgSlug) {
      setItems([]);
      setUnreadCount(0);
      return;
    }

    setLoading(true);
    try {
      const res = await fetch(`${base}/notifications`, {
        headers: {
          Authorization: `Bearer ${token}`,
          "x-org-slug": orgSlug,
        },
        cache: "no-store",
      });

      const data = await res.json().catch(() => null);
      if (!res.ok) {
        setItems([]);
        setUnreadCount(0);
        return;
      }

      setItems(data?.notifications ?? []);
      setUnreadCount(Number(data?.unreadCount ?? 0));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadNotifications();
    const timer = window.setInterval(loadNotifications, 30000);
    return () => window.clearInterval(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [base, token, orgSlug]);

  useEffect(() => {
    if (!token || !orgSlug) return;

    const source = new EventSource(
      `${base}/events/stream?token=${encodeURIComponent(token)}&orgSlug=${encodeURIComponent(orgSlug)}`
    );

    const refresh = () => {
      loadNotifications();
    };

    source.onmessage = refresh;
    source.addEventListener("notification", refresh);
    source.addEventListener("notification.read", refresh);
    source.addEventListener("notification.readAll", refresh);
    source.addEventListener("task.created", refresh);
    source.addEventListener("task.updated", refresh);
    source.addEventListener("task.deleted", refresh);
    source.addEventListener("task.commented", refresh);
    source.addEventListener("project.created", refresh);

    return () => {
      source.close();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [base, token, orgSlug]);

  async function markOneRead(id: string) {
    if (!token) return;

    await fetch(`${base}/notifications/${id}/read`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "x-org-slug": orgSlug,
      },
    });

    loadNotifications();
  }

  async function markAllRead() {
    if (!token) return;

    await fetch(`${base}/notifications/read-all`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "x-org-slug": orgSlug,
      },
    });

    loadNotifications();
  }

  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => setOpen((value) => !value)}
        className="relative rounded-2xl border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-700 shadow-sm transition hover:border-slate-300 hover:bg-slate-50"
      >
        Notifications
        {unreadCount > 0 ? (
          <span className="ml-2 inline-flex min-w-6 items-center justify-center rounded-full bg-slate-900 px-2 py-0.5 text-xs font-semibold text-white">
            {unreadCount > 99 ? "99+" : unreadCount}
          </span>
        ) : null}
      </button>

      {open ? (
        <div className="absolute right-0 top-14 z-40 w-[360px] overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-2xl">
          <div className="flex items-center justify-between border-b border-slate-200 px-4 py-3">
            <div>
              <div className="text-sm font-semibold text-slate-900">Inbox</div>
              <div className="text-xs text-slate-500">Live updates for your workspace</div>
            </div>

            <button
              type="button"
              onClick={markAllRead}
              className="text-xs font-semibold text-slate-600 transition hover:text-slate-900"
              disabled={!token || unreadCount === 0}
            >
              Mark all read
            </button>
          </div>

          <div className="max-h-[460px] overflow-y-auto">
            {!token ? (
              <div className="px-4 py-8 text-sm text-slate-500">Log in to see notifications.</div>
            ) : loading && items.length === 0 ? (
              <div className="px-4 py-8 text-sm text-slate-500">Loading notifications...</div>
            ) : items.length === 0 ? (
              <div className="px-4 py-8 text-sm text-slate-500">No activity yet.</div>
            ) : (
              items.map((item) => {
                const unread = !item.readAt;

                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => markOneRead(item.id)}
                    className={`block w-full border-b border-slate-100 px-4 py-3 text-left transition hover:bg-slate-50 ${
                      unread ? "bg-slate-50/80" : "bg-white"
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <div className="text-sm font-semibold text-slate-900">{item.title}</div>
                        {item.body ? (
                          <div className="mt-1 text-xs leading-5 text-slate-600">{item.body}</div>
                        ) : null}
                      </div>
                      {unread ? <span className="mt-1 h-2.5 w-2.5 rounded-full bg-sky-500" /> : null}
                    </div>
                    <div className="mt-2 text-[11px] uppercase tracking-[0.18em] text-slate-400">
                      {formatWhen(item.createdAt)}
                    </div>
                  </button>
                );
              })
            )}
          </div>
        </div>
      ) : null}
    </div>
  );
}
